# CAMPUS CONNECT – Smart College Event Management System

A MERN-stack college event-management mini project. The frontend is based on the React UI/source provided in `import React-0.docx`; a MongoDB-backed Express API and runnable Vite project scaffold have been added.

## Features included
- Premium dark dashboard and role-based demo views from the supplied React source
- Event list, event create/update/delete UI, categories, search and filters
- Student registrations and digital pass / QR demo screens
- Approvals, certificates, clubs, calendar, reports, feedback and settings modules
- MongoDB persistence for shared app state
- REST event CRUD endpoints
- API health endpoint
- LocalStorage fallback if the API is temporarily unavailable

## Requirements
- Node.js 18+ (recommended Node 20 LTS)
- MongoDB Community Server running locally, or a MongoDB Atlas connection string

## Installation and run

### 1. Configure MongoDB
Start MongoDB locally. Default connection: `mongodb://127.0.0.1:27017/campus_connect`

For a custom database, copy `server/.env.example` to `server/.env` and set `MONGODB_URI`.
Set `CLIENT_URL=http://localhost:5173` if using the default frontend address.

### 2. Install packages
From project root:
```bash
npm install
npm run install:all
```

### 3. Start frontend and backend
```bash
npm run dev
```
- Frontend: http://localhost:5173
- API: http://localhost:5000
- API health: http://localhost:5000/api/health

### 4. Build frontend
```bash
npm run build
```

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API status |
| GET | `/api/state` | Load saved app state |
| PUT | `/api/state/:key` | Save one state key |
| DELETE | `/api/state` | Clear stored demo state |
| GET | `/api/events` | List events |
| GET | `/api/events/:id` | Read one event |
| POST | `/api/events` | Create event (title, date, venue required) |
| PUT | `/api/events/:id` | Update event |
| DELETE | `/api/events/:id` | Delete event |

Allowed state keys: `viewMode`, `currentRole`, `events`, `registrations`, `certificates`, `clubs`, `notifications`, `feedbacks`.

## Project structure
```text
campus_connect_project/
├── client/
│   ├── index.html
│   ├── vite.config.js
│   └── src/
│       ├── App.jsx       # UI/modules from uploaded source, API persistence wired
│       ├── main.jsx
│       └── index.css
├── server/
│   ├── .env.example
│   └── src/
│       ├── models/AppState.js
│       ├── routes/stateRoutes.js
│       ├── routes/eventRoutes.js
│       └── server.js
├── package.json
└── README.md
```

## Notes
- Uploaded frontend role switching is a demo, not production authentication. Before using real student data, add secure login, password hashing, session/JWT management, server-side role authorization, validation and deployment secrets.
- QR passes/certificates are demo features; do not use them as verified campus credentials without backend verification.
- If MongoDB is not running, the backend will fail to start; the React client can still work with localStorage fallback when opened through Vite.
